import{l as o,a as r}from"../chunks/DvnEZZ_q.js";export{o as load_css,r as start};
