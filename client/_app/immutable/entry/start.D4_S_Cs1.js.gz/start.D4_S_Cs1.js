import{l as o,a as r}from"../chunks/D4_cn0Rs.js";export{o as load_css,r as start};
